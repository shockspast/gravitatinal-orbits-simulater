extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.
	get_tree().paused = true

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_settings_pressed() -> void:
	
	if $setings2.visible:
		$setings2.hide()
	else:
		$setings2.show()


func _on_launch_pressed() -> void:
	get_tree().paused = false


func _on_stop_pressed() -> void:
	get_tree().paused = true
