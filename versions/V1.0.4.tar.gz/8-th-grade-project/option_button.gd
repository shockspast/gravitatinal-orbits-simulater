extends OptionButton

func _ready() -> void:
	add_item("potato")    # 0
	add_item("very low") # 1
	add_item("low")      # 2
	add_item("mid")      # 3
	add_item("high")     # 4
	add_item("very high")# 5
	add_item("ultra")    # 6
	add_item("nasa pc")  # 7
	selected = 2

func _on_item_selected(index: int) -> void:
	# Get the main viewport and the active camera
	var vp = get_viewport()
	var cam = vp.get_camera_3d()
	
	match index:
		0: # Potato
			vp.msaa_3d = Viewport.MSAA_DISABLED
			if cam: cam.far = 50.0
		1: # Very Low
			vp.msaa_3d = Viewport.MSAA_DISABLED
			if cam: cam.far = 100.0
		2: # Low
			vp.msaa_3d = Viewport.MSAA_DISABLED
			if cam: cam.far = 250.0
		3: # Mid
			vp.msaa_3d = Viewport.MSAA_2X
			if cam: cam.far = 500.0
		4: # High
			vp.msaa_3d = Viewport.MSAA_2X
			if cam: cam.far = 1000.0
		5: # Very High
			vp.msaa_3d = Viewport.MSAA_4X
			if cam: cam.far = 2000.0
		6: # Ultra
			vp.msaa_3d = Viewport.MSAA_4X
			if cam: cam.far = 4000.0
		7: # NASA PC
			vp.msaa_3d = Viewport.MSAA_8X
			if cam: cam.far = 8000.0


func _on_check_box_toggled(toggled_on: bool) -> void:
	var fps_label = get_node("/root/Node3D/hud/fps")
	if toggled_on:
		print("Enabled!")
		fps_label.show()
	else:
		print("Disabled!")
		fps_label.hide()
func _process(delta: float) -> void:
	get_node("/root/Node3D/hud/fps").text = "FPS: " + str(Engine.get_frames_per_second())
